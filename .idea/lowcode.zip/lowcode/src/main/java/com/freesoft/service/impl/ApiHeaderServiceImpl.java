package com.freesoft.service.impl;

import com.freesoft.model.ApiHeaderDO;
import com.freesoft.mapper.ApiHeaderMapper;
import com.freesoft.service.ApiHeaderService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 请求头信息表 服务实现类
 * </p>
 *
 * @author zhouwei
 * @since 2022-07-26
 */
@Service
public class ApiHeaderServiceImpl extends ServiceImpl<ApiHeaderMapper, ApiHeaderDO> implements ApiHeaderService {

}

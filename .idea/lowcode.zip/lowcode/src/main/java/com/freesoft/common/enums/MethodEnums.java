package com.freesoft.common.enums;

/**
 * @author zhouwei
 */

public enum MethodEnums {
    GET,POST,PUT,DELETE;
}

package com.freesoft.service.impl;

import com.freesoft.model.ApiDataSourceDO;
import com.freesoft.mapper.ApiDataSourceMapper;
import com.freesoft.service.ApiDataSourceService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 数据源配置表 服务实现类
 * </p>
 *
 * @author zhouwei
 * @since 2022-07-26
 */
@Service
public class ApiDataSourceServiceImpl extends ServiceImpl<ApiDataSourceMapper, ApiDataSourceDO> implements ApiDataSourceService {

}

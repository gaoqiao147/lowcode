package com.freesoft.service.impl;

import com.freesoft.model.ApiParameterDO;
import com.freesoft.mapper.ApiParameterMapper;
import com.freesoft.service.ApiParameterService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 请求参数信息表 服务实现类
 * </p>
 *
 * @author zhouwei
 * @since 2022-07-26
 */
@Service
public class ApiParameterServiceImpl extends ServiceImpl<ApiParameterMapper, ApiParameterDO> implements ApiParameterService {

}

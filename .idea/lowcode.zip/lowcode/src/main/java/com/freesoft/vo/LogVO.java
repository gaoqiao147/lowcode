package com.freesoft.vo;

import lombok.Data;

/**
 * @author zhouwei
 */
@Data
public class LogVO {
    Object data;
}
